param(
    [switch]$SmokeTest
)

if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne "STA") {
    $quoted = '"' + $PSCommandPath + '"'
    $extra = ""
    if ($SmokeTest) {
        $extra = " -SmokeTest"
    }
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA -File $quoted$extra"
    exit
}

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

$AppName = "X-tra X-ray"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
$ConfigPath = Join-Path $Root "config\invisible_blocks.txt"
$VisibleConfigPath = Join-Path $Root "config\visible_blocks.txt"
$ModePath = Join-Path $Root "config\mode.txt"
$CatalogPath = Join-Path $Root "config\block_catalog.txt"
$BuilderPath = Join-Path $Root "tools\Build-XtraXray.ps1"
$OutputPath = Join-Path $Root "X-tra X-ray.mcpack"

function Normalize-BlockId {
    param([string]$Value)

    $id = $Value.Trim().ToLowerInvariant()
    if (-not $id) {
        return $null
    }
    if ($id -notmatch ":") {
        $id = "minecraft:$id"
    }
    if ($id -notmatch "^[a-z0-9_.-]+:[a-z0-9_.-]+$") {
        throw "Use a block ID like minecraft:stone."
    }
    return $id
}

function Read-BlockIds {
    param([string]$Path = $ConfigPath)

    if (-not (Test-Path $Path)) {
        return @()
    }

    $text = Get-Content -Raw -LiteralPath $Path
    $withoutComments = ($text -split "`r?`n" | ForEach-Object {
        ($_ -replace "#.*$", "").Trim()
    }) -join " "

    $seen = @{}
    $ids = New-Object System.Collections.Generic.List[string]
    foreach ($token in ($withoutComments -split "[,\s;]+")) {
        if (-not $token.Trim()) {
            continue
        }
        $id = Normalize-BlockId $token
        if (-not $seen.ContainsKey($id)) {
            $seen[$id] = $true
            $ids.Add($id) | Out-Null
        }
    }
    return $ids.ToArray()
}

function Save-BlockIds {
    param(
        [string[]]$Ids,
        [string]$Path = $ConfigPath,
        [string]$Title = "Type the blocks you want hidden."
    )

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("# $Title") | Out-Null
    $lines.Add("# You can use commas, spaces, or new lines.") | Out-Null
    $lines.Add("# Lines beginning with # are ignored.") | Out-Null
    $lines.Add("") | Out-Null
    foreach ($id in $Ids) {
        $lines.Add($id) | Out-Null
    }
    Set-Content -LiteralPath $Path -Value $lines -Encoding UTF8
}

function Add-BlockId {
    param(
        [string]$Value,
        [System.Windows.Forms.ListBox]$List = $blockList
    )

    $id = Normalize-BlockId $Value
    if (-not $id) {
        return
    }
    foreach ($item in $List.Items) {
        if ($item -eq $id) {
            return
        }
    }
    $List.Items.Add($id) | Out-Null
}

function Set-Blocks {
    param(
        [string[]]$Ids,
        [System.Windows.Forms.ListBox]$List = $blockList
    )

    $List.Items.Clear()
    foreach ($id in $Ids) {
        Add-BlockId -Value $id -List $List
    }
}

function Get-Blocks {
    param([System.Windows.Forms.ListBox]$List = $blockList)

    $ids = New-Object System.Collections.Generic.List[string]
    foreach ($item in $List.Items) {
        $ids.Add([string]$item) | Out-Null
    }
    return $ids.ToArray()
}

function Set-Status {
    param([string]$Text)
    $statusLabel.Text = $Text
}

$form = New-Object System.Windows.Forms.Form
$form.Text = $AppName
$form.StartPosition = "CenterScreen"
$form.Size = New-Object System.Drawing.Size(1180, 700)
$form.MinimumSize = New-Object System.Drawing.Size(1080, 620)
$form.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = $AppName
$title.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 22)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(24, 18)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "Minecraft Bedrock invisible-block pack builder"
$subtitle.AutoSize = $true
$subtitle.ForeColor = [System.Drawing.Color]::FromArgb(78, 87, 98)
$subtitle.Location = New-Object System.Drawing.Point(28, 62)
$form.Controls.Add($subtitle)

$leftGroup = New-Object System.Windows.Forms.GroupBox
$leftGroup.Text = "Invisible Blocks"
$leftGroup.Location = New-Object System.Drawing.Point(24, 100)
$leftGroup.Size = New-Object System.Drawing.Size(360, 430)
$leftGroup.Anchor = "Top,Bottom,Left"
$form.Controls.Add($leftGroup)

$blockList = New-Object System.Windows.Forms.ListBox
$blockList.Location = New-Object System.Drawing.Point(18, 30)
$blockList.Size = New-Object System.Drawing.Size(324, 250)
$blockList.Anchor = "Top,Bottom,Left,Right"
$blockList.SelectionMode = "MultiExtended"
$leftGroup.Controls.Add($blockList)

$blockInput = New-Object System.Windows.Forms.TextBox
$blockInput.Location = New-Object System.Drawing.Point(92, 293)
$blockInput.Size = New-Object System.Drawing.Size(134, 28)
$blockInput.Anchor = "Bottom,Left,Right"
$leftGroup.Controls.Add($blockInput)

$blockInputLabel = New-Object System.Windows.Forms.Label
$blockInputLabel.Text = "Block ID"
$blockInputLabel.Location = New-Object System.Drawing.Point(18, 278)
$blockInputLabel.Location = New-Object System.Drawing.Point(18, 298)
$blockInputLabel.Size = New-Object System.Drawing.Size(65, 22)
$blockInputLabel.Anchor = "Bottom,Left"
$leftGroup.Controls.Add($blockInputLabel)

$addButton = New-Object System.Windows.Forms.Button
$addButton.Text = "Add"
$addButton.Location = New-Object System.Drawing.Point(238, 291)
$addButton.Size = New-Object System.Drawing.Size(104, 32)
$addButton.Anchor = "Bottom,Right"
$leftGroup.Controls.Add($addButton)

$removeButton = New-Object System.Windows.Forms.Button
$removeButton.Text = "Remove Selected"
$removeButton.Location = New-Object System.Drawing.Point(18, 382)
$removeButton.Size = New-Object System.Drawing.Size(150, 32)
$removeButton.Anchor = "Bottom,Right"
$leftGroup.Controls.Add($removeButton)

$pasteBox = New-Object System.Windows.Forms.TextBox
$pasteBox.Location = New-Object System.Drawing.Point(92, 338)
$pasteBox.Size = New-Object System.Drawing.Size(134, 28)
$pasteBox.Anchor = "Bottom,Left,Right"
$leftGroup.Controls.Add($pasteBox)

$pasteBoxLabel = New-Object System.Windows.Forms.Label
$pasteBoxLabel.Text = "Many IDs"
$pasteBoxLabel.Location = New-Object System.Drawing.Point(18, 323)
$pasteBoxLabel.Location = New-Object System.Drawing.Point(18, 343)
$pasteBoxLabel.Size = New-Object System.Drawing.Size(65, 22)
$pasteBoxLabel.Anchor = "Bottom,Left"
$leftGroup.Controls.Add($pasteBoxLabel)

$pasteButton = New-Object System.Windows.Forms.Button
$pasteButton.Text = "Add Many"
$pasteButton.Location = New-Object System.Drawing.Point(238, 336)
$pasteButton.Size = New-Object System.Drawing.Size(104, 32)
$pasteButton.Anchor = "Bottom,Right"
$leftGroup.Controls.Add($pasteButton)

$visibleGroup = New-Object System.Windows.Forms.GroupBox
$visibleGroup.Text = "Visible Blocks"
$visibleGroup.Location = New-Object System.Drawing.Point(400, 100)
$visibleGroup.Size = New-Object System.Drawing.Size(360, 430)
$visibleGroup.Anchor = "Top,Bottom,Left"
$form.Controls.Add($visibleGroup)

$visibleList = New-Object System.Windows.Forms.ListBox
$visibleList.Location = New-Object System.Drawing.Point(18, 30)
$visibleList.Size = New-Object System.Drawing.Size(324, 250)
$visibleList.Anchor = "Top,Bottom,Left,Right"
$visibleList.SelectionMode = "MultiExtended"
$visibleGroup.Controls.Add($visibleList)

$visibleInput = New-Object System.Windows.Forms.TextBox
$visibleInput.Location = New-Object System.Drawing.Point(92, 293)
$visibleInput.Size = New-Object System.Drawing.Size(134, 28)
$visibleInput.Anchor = "Bottom,Left,Right"
$visibleGroup.Controls.Add($visibleInput)

$visibleInputLabel = New-Object System.Windows.Forms.Label
$visibleInputLabel.Text = "Block ID"
$visibleInputLabel.Location = New-Object System.Drawing.Point(18, 298)
$visibleInputLabel.Size = New-Object System.Drawing.Size(65, 22)
$visibleInputLabel.Anchor = "Bottom,Left"
$visibleGroup.Controls.Add($visibleInputLabel)

$visibleAddButton = New-Object System.Windows.Forms.Button
$visibleAddButton.Text = "Add"
$visibleAddButton.Location = New-Object System.Drawing.Point(238, 291)
$visibleAddButton.Size = New-Object System.Drawing.Size(104, 32)
$visibleAddButton.Anchor = "Bottom,Right"
$visibleGroup.Controls.Add($visibleAddButton)

$visiblePasteBox = New-Object System.Windows.Forms.TextBox
$visiblePasteBox.Location = New-Object System.Drawing.Point(92, 338)
$visiblePasteBox.Size = New-Object System.Drawing.Size(134, 28)
$visiblePasteBox.Anchor = "Bottom,Left,Right"
$visibleGroup.Controls.Add($visiblePasteBox)

$visiblePasteLabel = New-Object System.Windows.Forms.Label
$visiblePasteLabel.Text = "Many IDs"
$visiblePasteLabel.Location = New-Object System.Drawing.Point(18, 343)
$visiblePasteLabel.Size = New-Object System.Drawing.Size(65, 22)
$visiblePasteLabel.Anchor = "Bottom,Left"
$visibleGroup.Controls.Add($visiblePasteLabel)

$visiblePasteButton = New-Object System.Windows.Forms.Button
$visiblePasteButton.Text = "Add Many"
$visiblePasteButton.Location = New-Object System.Drawing.Point(238, 336)
$visiblePasteButton.Size = New-Object System.Drawing.Size(104, 32)
$visiblePasteButton.Anchor = "Bottom,Right"
$visibleGroup.Controls.Add($visiblePasteButton)

$visibleRemoveButton = New-Object System.Windows.Forms.Button
$visibleRemoveButton.Text = "Remove Selected"
$visibleRemoveButton.Location = New-Object System.Drawing.Point(18, 382)
$visibleRemoveButton.Size = New-Object System.Drawing.Size(150, 32)
$visibleRemoveButton.Anchor = "Bottom,Left"
$visibleGroup.Controls.Add($visibleRemoveButton)

$visibleClearButton = New-Object System.Windows.Forms.Button
$visibleClearButton.Text = "Clear List"
$visibleClearButton.Location = New-Object System.Drawing.Point(238, 382)
$visibleClearButton.Size = New-Object System.Drawing.Size(104, 32)
$visibleClearButton.Anchor = "Bottom,Right"
$visibleGroup.Controls.Add($visibleClearButton)

$rightGroup = New-Object System.Windows.Forms.GroupBox
$rightGroup.Text = "Build Mode and Presets"
$rightGroup.Location = New-Object System.Drawing.Point(784, 100)
$rightGroup.Size = New-Object System.Drawing.Size(332, 430)
$rightGroup.Anchor = "Top,Bottom,Right"
$form.Controls.Add($rightGroup)

$hideModeRadio = New-Object System.Windows.Forms.RadioButton
$hideModeRadio.Text = "Hide selected blocks"
$hideModeRadio.Location = New-Object System.Drawing.Point(22, 30)
$hideModeRadio.Size = New-Object System.Drawing.Size(288, 24)
$hideModeRadio.Checked = $true
$rightGroup.Controls.Add($hideModeRadio)

$showOnlyModeRadio = New-Object System.Windows.Forms.RadioButton
$showOnlyModeRadio.Text = "Show only visible list"
$showOnlyModeRadio.Location = New-Object System.Drawing.Point(22, 58)
$showOnlyModeRadio.Size = New-Object System.Drawing.Size(288, 24)
$rightGroup.Controls.Add($showOnlyModeRadio)

$presetStone = New-Object System.Windows.Forms.Button
$presetStone.Text = "Stone Trio"
$presetStone.Location = New-Object System.Drawing.Point(22, 96)
$presetStone.Size = New-Object System.Drawing.Size(288, 38)
$rightGroup.Controls.Add($presetStone)

$presetOverworld = New-Object System.Windows.Forms.Button
$presetOverworld.Text = "Overworld Mining"
$presetOverworld.Location = New-Object System.Drawing.Point(22, 140)
$presetOverworld.Size = New-Object System.Drawing.Size(288, 38)
$rightGroup.Controls.Add($presetOverworld)

$presetDeep = New-Object System.Windows.Forms.Button
$presetDeep.Text = "Deep Mining"
$presetDeep.Location = New-Object System.Drawing.Point(22, 184)
$presetDeep.Size = New-Object System.Drawing.Size(288, 38)
$rightGroup.Controls.Add($presetDeep)

$presetNether = New-Object System.Windows.Forms.Button
$presetNether.Text = "Nether Mining"
$presetNether.Location = New-Object System.Drawing.Point(22, 228)
$presetNether.Size = New-Object System.Drawing.Size(288, 38)
$rightGroup.Controls.Add($presetNether)

$loadButton = New-Object System.Windows.Forms.Button
$loadButton.Text = "Reload Saved"
$loadButton.Location = New-Object System.Drawing.Point(22, 286)
$loadButton.Size = New-Object System.Drawing.Size(288, 38)
$rightGroup.Controls.Add($loadButton)

$clearButton = New-Object System.Windows.Forms.Button
$clearButton.Text = "Clear Hidden List"
$clearButton.Location = New-Object System.Drawing.Point(22, 330)
$clearButton.Size = New-Object System.Drawing.Size(288, 38)
$rightGroup.Controls.Add($clearButton)

$countLabel = New-Object System.Windows.Forms.Label
$countLabel.Text = "0 blocks selected"
$countLabel.Location = New-Object System.Drawing.Point(22, 378)
$countLabel.Size = New-Object System.Drawing.Size(288, 24)
$countLabel.ForeColor = [System.Drawing.Color]::FromArgb(78, 87, 98)
$rightGroup.Controls.Add($countLabel)

$visibleCountLabel = New-Object System.Windows.Forms.Label
$visibleCountLabel.Text = "0 visible blocks selected"
$visibleCountLabel.Location = New-Object System.Drawing.Point(22, 400)
$visibleCountLabel.Size = New-Object System.Drawing.Size(288, 24)
$visibleCountLabel.ForeColor = [System.Drawing.Color]::FromArgb(78, 87, 98)
$rightGroup.Controls.Add($visibleCountLabel)

$bottomGroup = New-Object System.Windows.Forms.GroupBox
$bottomGroup.Text = "Pack"
$bottomGroup.Location = New-Object System.Drawing.Point(24, 548)
$bottomGroup.Size = New-Object System.Drawing.Size(1092, 80)
$bottomGroup.Anchor = "Bottom,Left,Right"
$form.Controls.Add($bottomGroup)

$buildButton = New-Object System.Windows.Forms.Button
$buildButton.Text = "Build .mcpack"
$buildButton.Location = New-Object System.Drawing.Point(18, 26)
$buildButton.Size = New-Object System.Drawing.Size(140, 32)
$bottomGroup.Controls.Add($buildButton)

$importButton = New-Object System.Windows.Forms.Button
$importButton.Text = "Import"
$importButton.Location = New-Object System.Drawing.Point(170, 26)
$importButton.Size = New-Object System.Drawing.Size(100, 32)
$bottomGroup.Controls.Add($importButton)

$folderButton = New-Object System.Windows.Forms.Button
$folderButton.Text = "Open Folder"
$folderButton.Location = New-Object System.Drawing.Point(282, 26)
$folderButton.Size = New-Object System.Drawing.Size(120, 32)
$bottomGroup.Controls.Add($folderButton)

$outputLabel = New-Object System.Windows.Forms.Label
$outputLabel.Text = $OutputPath
$outputLabel.Location = New-Object System.Drawing.Point(420, 32)
$outputLabel.Size = New-Object System.Drawing.Size(390, 20)
$outputLabel.Anchor = "Top,Left,Right"
$outputLabel.ForeColor = [System.Drawing.Color]::FromArgb(78, 87, 98)
$bottomGroup.Controls.Add($outputLabel)

$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Text = "Ready"
$statusStrip.Items.Add($statusLabel) | Out-Null
$form.Controls.Add($statusStrip)

function Update-Count {
    $countLabel.Text = "$($blockList.Items.Count) hidden blocks selected"
    $visibleCountLabel.Text = "$($visibleList.Items.Count) visible blocks selected"
}

function Get-BuildMode {
    if ($showOnlyModeRadio.Checked) {
        return "show_only"
    }
    return "hide"
}

function Save-BuildMode {
    Set-Content -LiteralPath $ModePath -Value (Get-BuildMode) -Encoding UTF8
}

function Load-BuildMode {
    if (Test-Path $ModePath) {
        $mode = (Get-Content -Raw -LiteralPath $ModePath).Trim().ToLowerInvariant()
        if ($mode -match "show|visible") {
            $showOnlyModeRadio.Checked = $true
            return
        }
    }
    $hideModeRadio.Checked = $true
}

$addButton.Add_Click({
    try {
        Add-BlockId $blockInput.Text
        $blockInput.Clear()
        Update-Count
        Set-Status "Block added."
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, $AppName, "OK", "Warning") | Out-Null
    }
})

$blockInput.Add_KeyDown({
    if ($_.KeyCode -eq "Enter") {
        $addButton.PerformClick()
        $_.SuppressKeyPress = $true
    }
})

$pasteButton.Add_Click({
    try {
        foreach ($token in ($pasteBox.Text -split "[,\s;]+")) {
            if ($token.Trim()) {
                Add-BlockId $token
            }
        }
        $pasteBox.Clear()
        Update-Count
        Set-Status "Blocks added."
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, $AppName, "OK", "Warning") | Out-Null
    }
})

$visibleAddButton.Add_Click({
    try {
        Add-BlockId -Value $visibleInput.Text -List $visibleList
        $visibleInput.Clear()
        Update-Count
        Set-Status "Visible block added."
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, $AppName, "OK", "Warning") | Out-Null
    }
})

$visibleInput.Add_KeyDown({
    if ($_.KeyCode -eq "Enter") {
        $visibleAddButton.PerformClick()
        $_.SuppressKeyPress = $true
    }
})

$visiblePasteButton.Add_Click({
    try {
        foreach ($token in ($visiblePasteBox.Text -split "[,\s;]+")) {
            if ($token.Trim()) {
                Add-BlockId -Value $token -List $visibleList
            }
        }
        $visiblePasteBox.Clear()
        Update-Count
        Set-Status "Visible blocks added."
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, $AppName, "OK", "Warning") | Out-Null
    }
})

$visibleRemoveButton.Add_Click({
    $selected = @($visibleList.SelectedItems)
    foreach ($item in $selected) {
        $visibleList.Items.Remove($item)
    }
    Update-Count
    Set-Status "Visible selection removed."
})

$visibleClearButton.Add_Click({
    $visibleList.Items.Clear()
    Update-Count
    Set-Status "Visible list cleared."
})

$removeButton.Add_Click({
    $selected = @($blockList.SelectedItems)
    foreach ($item in $selected) {
        $blockList.Items.Remove($item)
    }
    Update-Count
    Set-Status "Selection removed."
})

$clearButton.Add_Click({
    $blockList.Items.Clear()
    Update-Count
    Set-Status "List cleared."
})

$presetStone.Add_Click({
    Set-Blocks @("minecraft:stone", "minecraft:andesite", "minecraft:diorite")
    Update-Count
    Set-Status "Stone Trio loaded."
})

$presetOverworld.Add_Click({
    Set-Blocks @(
        "minecraft:stone",
        "minecraft:granite",
        "minecraft:andesite",
        "minecraft:diorite",
        "minecraft:dirt",
        "minecraft:gravel",
        "minecraft:sand",
        "minecraft:sandstone",
        "minecraft:clay",
        "minecraft:tuff",
        "minecraft:calcite"
    )
    Update-Count
    Set-Status "Overworld Mining loaded."
})

$presetDeep.Add_Click({
    Set-Blocks @(
        "minecraft:stone",
        "minecraft:deepslate",
        "minecraft:tuff",
        "minecraft:basalt",
        "minecraft:smooth_basalt",
        "minecraft:dripstone_block",
        "minecraft:gravel",
        "minecraft:dirt"
    )
    Update-Count
    Set-Status "Deep Mining loaded."
})

$presetNether.Add_Click({
    Set-Blocks @(
        "minecraft:netherrack",
        "minecraft:basalt",
        "minecraft:blackstone",
        "minecraft:soul_sand",
        "minecraft:soul_soil",
        "minecraft:gravel",
        "minecraft:magma"
    )
    Update-Count
    Set-Status "Nether Mining loaded."
})

$loadButton.Add_Click({
    try {
        Set-Blocks -Ids (Read-BlockIds -Path $ConfigPath) -List $blockList
        Set-Blocks -Ids (Read-BlockIds -Path $VisibleConfigPath) -List $visibleList
        Load-BuildMode
        Update-Count
        Set-Status "Saved lists loaded."
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, $AppName, "OK", "Error") | Out-Null
    }
})

$buildButton.Add_Click({
    try {
        $hiddenIds = Get-Blocks -List $blockList
        $visibleIds = Get-Blocks -List $visibleList
        $mode = Get-BuildMode

        if (($mode -eq "hide") -and ($hiddenIds.Count -eq 0)) {
            [System.Windows.Forms.MessageBox]::Show("Add at least one hidden block first.", $AppName, "OK", "Warning") | Out-Null
            return
        }
        if (($mode -eq "show_only") -and ($visibleIds.Count -eq 0)) {
            [System.Windows.Forms.MessageBox]::Show("Add at least one visible block first.", $AppName, "OK", "Warning") | Out-Null
            return
        }

        Save-BlockIds -Ids $hiddenIds -Path $ConfigPath -Title "Type the blocks you want hidden."
        Save-BlockIds -Ids $visibleIds -Path $VisibleConfigPath -Title "Type the only blocks you want visible when using Show Only mode."
        Save-BuildMode
        Set-Status "Building pack..."
        $form.Refresh()

        $process = Start-Process powershell.exe -Wait -PassThru -WindowStyle Hidden -ArgumentList @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", "`"$BuilderPath`"",
            "-ConfigPath", "`"$ConfigPath`"",
            "-VisibleConfigPath", "`"$VisibleConfigPath`"",
            "-ModePath", "`"$ModePath`"",
            "-CatalogPath", "`"$CatalogPath`"",
            "-PackRoot", "`"$(Join-Path $Root "pack")`"",
            "-OutputPath", "`"$OutputPath`""
        )

        if ($process.ExitCode -ne 0) {
            throw "The pack builder did not finish successfully."
        }

        Set-Status "Built X-tra X-ray.mcpack."
        [System.Windows.Forms.MessageBox]::Show("Built X-tra X-ray.mcpack.", $AppName, "OK", "Information") | Out-Null
    }
    catch {
        Set-Status "Build failed."
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, $AppName, "OK", "Error") | Out-Null
    }
})

$importButton.Add_Click({
    if (-not (Test-Path $OutputPath)) {
        [System.Windows.Forms.MessageBox]::Show("Build the pack first.", $AppName, "OK", "Warning") | Out-Null
        return
    }
    Start-Process -FilePath $OutputPath
    Set-Status "Opening pack import."
})

$folderButton.Add_Click({
    Start-Process explorer.exe -ArgumentList "`"$Root`""
})

try {
    Set-Blocks -Ids (Read-BlockIds -Path $ConfigPath) -List $blockList
    Set-Blocks -Ids (Read-BlockIds -Path $VisibleConfigPath) -List $visibleList
    Load-BuildMode
    Update-Count
}
catch {
    Set-Status "Could not load saved list."
}

if ($SmokeTest) {
    Write-Host "X-tra X-ray app loaded."
    return
}

[void][System.Windows.Forms.Application]::Run($form)
