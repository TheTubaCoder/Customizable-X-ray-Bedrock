# X-tra X-ray

Client-side Minecraft Bedrock x-ray resource pack app for making selected blocks invisible.

## What this can do

- Hide multiple Bedrock block IDs at once, such as `minecraft:stone`, `minecraft:andesite`, and `minecraft:diorite`.
- Build an importable `.mcpack` file for Minecraft Bedrock on Windows.
- Keep this as a resource pack only, so it does not need a behavior pack and should not disable achievements by itself.

## What Minecraft will not allow

Bedrock resource packs cannot add a live in-game text box or change the selected block list while a world is running. To change the invisible blocks, edit the list, rebuild the `.mcpack`, and reload/reapply the pack in Minecraft.

## How to choose blocks

Open the app from the Start Menu/Desktop shortcut after installing, or launch it directly:

```text
app/Launch X-tra X-ray.cmd
```

You can also edit the plain block list by opening:

```text
config/invisible_blocks.txt
```

Put block IDs there, separated by commas, spaces, or new lines.

Example:

```text
minecraft:stone
minecraft:andesite
minecraft:diorite
```

Short names also work. For example, `stone` is treated as `minecraft:stone`.

The app has two modes:

- **Hide selected blocks** makes the blocks in the Invisible Blocks section invisible.
- **Show only visible list** hides everything in `config/block_catalog.txt` except the blocks in the Visible Blocks section.

## Build the pack

Double-click `Build X-tra Xray.cmd`, or press **Build .mcpack** in the app, and it will create:

```text
X-tra X-ray.mcpack
```

Double-click the `.mcpack` to import it into Minecraft Bedrock, then activate it from the resource pack screen.

## Install the app

Double-click:

```text
Install X-tra X-ray.cmd
```

This installs a copy to:

```text
%LOCALAPPDATA%\Programs\X-tra X-ray
```

It also creates Desktop and Start Menu shortcuts, plus a Start Menu shortcut named **Open X-tra X-ray Files**.

If you want the whole app folder directly on your Desktop instead, double-click:

```text
Install X-tra X-ray on Desktop.cmd
```

## Notes

- This pack is meant for single-player/testing use. Servers and Realms may have rules against x-ray resource packs.
- Use night vision or a full-bright pack with higher priority if the hidden area is too dark.
- If a future Bedrock update changes how vanilla block shapes are handled, rebuild first; if it still fails, the pack may need an update.
