param(
    [string]$InstallRoot,
    [switch]$DesktopInstall,
    [switch]$NoStartMenu
)

$ErrorActionPreference = "Stop"

$SourceRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$Desktop = [Environment]::GetFolderPath("Desktop")
if (-not $Desktop) {
    $Desktop = [Environment]::GetFolderPath("DesktopDirectory")
}
if ((-not $Desktop) -or (-not (Test-Path $Desktop))) {
    $OneDriveDesktop = Join-Path $env:USERPROFILE "OneDrive\Desktop"
    if (Test-Path $OneDriveDesktop) {
        $Desktop = $OneDriveDesktop
    }
}
if (-not $Desktop) {
    $Desktop = Join-Path $env:USERPROFILE "Desktop"
}
if (-not $InstallRoot) {
    if ($DesktopInstall) {
        $InstallRoot = Join-Path $Desktop "X-tra X-ray"
    }
    else {
        $InstallRoot = Join-Path $env:LOCALAPPDATA "Programs\X-tra X-ray"
    }
}
$AppScript = Join-Path $InstallRoot "app\X-tra X-ray.ps1"
$StartMenuFolder = $null
if (-not $NoStartMenu) {
    $StartMenuFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "X-tra X-ray"
}
$PowerShell = (Get-Command powershell.exe).Source

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
New-Item -ItemType Directory -Force -Path $Desktop | Out-Null
if ($StartMenuFolder) {
    New-Item -ItemType Directory -Force -Path $StartMenuFolder | Out-Null
}

foreach ($Dir in @("app", "pack", "tools")) {
    $Source = Join-Path $SourceRoot $Dir
    $Destination = Join-Path $InstallRoot $Dir
    if (Test-Path $Destination) {
        Remove-Item -LiteralPath $Destination -Recurse -Force
    }
    Copy-Item -LiteralPath $Source -Destination $InstallRoot -Recurse
}

$InstalledConfig = Join-Path $InstallRoot "config"
if (-not (Test-Path $InstalledConfig)) {
    Copy-Item -LiteralPath (Join-Path $SourceRoot "config") -Destination $InstallRoot -Recurse
}
else {
    foreach ($ConfigFile in Get-ChildItem -LiteralPath (Join-Path $SourceRoot "config") -File) {
        $TargetConfigFile = Join-Path $InstalledConfig $ConfigFile.Name
        if (-not (Test-Path $TargetConfigFile)) {
            Copy-Item -LiteralPath $ConfigFile.FullName -Destination $TargetConfigFile
        }
    }
}

foreach ($File in @("README.md", "Build X-tra Xray.cmd", "Uninstall X-tra X-ray.cmd")) {
    Copy-Item -LiteralPath (Join-Path $SourceRoot $File) -Destination $InstallRoot -Force
}

$Shell = New-Object -ComObject WScript.Shell

$AppShortcuts = @(
    (Join-Path $Desktop "X-tra X-ray.lnk")
)
if ($StartMenuFolder) {
    $AppShortcuts += (Join-Path $StartMenuFolder "X-tra X-ray.lnk")
}

foreach ($Path in $AppShortcuts) {
    $Shortcut = $Shell.CreateShortcut($Path)
    $Shortcut.TargetPath = $PowerShell
    $Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File `"$AppScript`""
    $Shortcut.WorkingDirectory = $InstallRoot
    $Shortcut.Description = "X-tra X-ray Minecraft Bedrock pack builder"
    $Shortcut.Save()
}

if ($StartMenuFolder) {
    $FolderShortcut = $Shell.CreateShortcut((Join-Path $StartMenuFolder "Open X-tra X-ray Files.lnk"))
    $FolderShortcut.TargetPath = $InstallRoot
    $FolderShortcut.WorkingDirectory = $InstallRoot
    $FolderShortcut.Description = "Open the installed X-tra X-ray files"
    $FolderShortcut.Save()
}

Write-Host "Installed X-tra X-ray to:"
Write-Host $InstallRoot
Write-Host "Desktop and Start Menu shortcuts are ready."
