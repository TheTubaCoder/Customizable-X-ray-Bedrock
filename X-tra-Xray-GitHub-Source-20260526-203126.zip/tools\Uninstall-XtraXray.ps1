param(
    [switch]$DesktopInstall
)

$Desktop = [Environment]::GetFolderPath("Desktop")
if (-not $Desktop) {
    $Desktop = [Environment]::GetFolderPath("DesktopDirectory")
}
if ((-not $Desktop) -or (-not (Test-Path $Desktop))) {
    $OneDriveDesktop = Join-Path $env:USERPROFILE "OneDrive\Desktop"
    if (Test-Path $OneDriveDesktop) {
        $Desktop = $OneDriveDesktop
    }
}
if (-not $Desktop) {
    $Desktop = Join-Path $env:USERPROFILE "Desktop"
}
$StartMenuFolder = Join-Path ([Environment]::GetFolderPath("Programs")) "X-tra X-ray"
$InstallRoot = Join-Path $env:LOCALAPPDATA "Programs\X-tra X-ray"
if ($DesktopInstall) {
    $InstallRoot = Join-Path $Desktop "X-tra X-ray"
}

Remove-Item -LiteralPath (Join-Path $Desktop "X-tra X-ray.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $StartMenuFolder -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $InstallRoot -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "Removed X-tra X-ray shortcuts and installed files."
