@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Uninstall-XtraXray.ps1" -DesktopInstall
echo.
pause
