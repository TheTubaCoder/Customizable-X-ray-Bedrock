@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Build-XtraXray.ps1"
echo.
pause
