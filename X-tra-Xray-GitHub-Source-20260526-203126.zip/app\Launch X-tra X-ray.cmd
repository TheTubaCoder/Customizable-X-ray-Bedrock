@echo off
setlocal
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "%~dp0X-tra X-ray.ps1"
