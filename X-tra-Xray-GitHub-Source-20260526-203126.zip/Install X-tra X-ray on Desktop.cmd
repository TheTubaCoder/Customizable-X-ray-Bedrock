@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Install-XtraXray.ps1" -DesktopInstall -NoStartMenu
echo.
pause
