param(
    [string]$ConfigPath,
    [string]$VisibleConfigPath,
    [string]$ModePath,
    [string]$CatalogPath,
    [string]$PackRoot,
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Resolve-Path (Join-Path $ScriptDir "..")

if (-not $ConfigPath) {
    $ConfigPath = Join-Path $Root "config\invisible_blocks.txt"
}
if (-not $VisibleConfigPath) {
    $VisibleConfigPath = Join-Path $Root "config\visible_blocks.txt"
}
if (-not $ModePath) {
    $ModePath = Join-Path $Root "config\mode.txt"
}
if (-not $CatalogPath) {
    $CatalogPath = Join-Path $Root "config\block_catalog.txt"
}
if (-not $PackRoot) {
    $PackRoot = Join-Path $Root "pack"
}
if (-not $OutputPath) {
    $OutputPath = Join-Path $Root "X-tra X-ray.mcpack"
}

function ConvertTo-BlockIdList {
    param([string]$Text)

    $withoutComments = ($Text -split "`r?`n" | ForEach-Object {
        ($_ -replace "#.*$", "").Trim()
    }) -join " "

    $tokens = $withoutComments -split "[,\s;]+" | Where-Object { $_ -and $_.Trim() }
    $seen = @{}
    $ids = New-Object System.Collections.Generic.List[string]

    foreach ($token in $tokens) {
        $id = $token.Trim().ToLowerInvariant()
        if ($id -notmatch ":") {
            $id = "minecraft:$id"
        }
        if ($id -notmatch "^[a-z0-9_.-]+:[a-z0-9_.-]+$") {
            throw "Invalid block ID '$token'. Use IDs like minecraft:stone."
        }
        if (-not $seen.ContainsKey($id)) {
            $seen[$id] = $true
            $ids.Add($id) | Out-Null
        }
    }

    return $ids
}

function New-TransparentPng {
    param([string]$Path)

    if (Test-Path $Path) {
        return
    }

    Add-Type -AssemblyName System.Drawing
    $bitmap = New-Object System.Drawing.Bitmap 16, 16, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $bitmap.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bitmap.Dispose()
}

function New-PackIcon {
    param([string]$Path)

    if (Test-Path $Path) {
        return
    }

    Add-Type -AssemblyName System.Drawing
    $bitmap = New-Object System.Drawing.Bitmap 256, 256, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.Clear([System.Drawing.Color]::FromArgb(255, 18, 20, 24))

    $greenBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 99, 255, 150))
    $darkBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 28, 36, 38))
    $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(255, 99, 255, 150)), 8

    $graphics.FillRectangle($darkBrush, 36, 48, 184, 160)
    $graphics.DrawRectangle($pen, 36, 48, 184, 160)
    $graphics.FillEllipse($greenBrush, 86, 82, 32, 32)
    $graphics.FillEllipse($greenBrush, 138, 82, 32, 32)
    $graphics.FillRectangle($greenBrush, 74, 152, 108, 18)

    $graphics.Dispose()
    $greenBrush.Dispose()
    $darkBrush.Dispose()
    $pen.Dispose()
    $bitmap.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bitmap.Dispose()
}

if (-not (Test-Path $PackRoot)) {
    throw "Could not find pack folder: $PackRoot"
}

$mode = "hide"
if (Test-Path $ModePath) {
    $modeText = (Get-Content -Raw -LiteralPath $ModePath).Trim().ToLowerInvariant()
    if ($modeText -match "show|visible") {
        $mode = "show_only"
    }
}

if ($mode -eq "show_only") {
    if (-not (Test-Path $VisibleConfigPath)) {
        throw "Could not find visible block list: $VisibleConfigPath"
    }
    if (-not (Test-Path $CatalogPath)) {
        throw "Could not find block catalog: $CatalogPath"
    }

    $visibleIds = ConvertTo-BlockIdList -Text (Get-Content -Raw -LiteralPath $VisibleConfigPath)
    $catalogIds = ConvertTo-BlockIdList -Text (Get-Content -Raw -LiteralPath $CatalogPath)
    if ($visibleIds.Count -eq 0) {
        throw "No visible block IDs were found in $VisibleConfigPath."
    }
    if ($catalogIds.Count -eq 0) {
        throw "No block IDs were found in $CatalogPath."
    }

    $visibleLookup = @{}
    foreach ($id in $visibleIds) {
        $visibleLookup[$id] = $true
    }

    $ids = New-Object System.Collections.Generic.List[string]
    foreach ($id in $catalogIds) {
        if (-not $visibleLookup.ContainsKey($id)) {
            $ids.Add($id) | Out-Null
        }
    }
}
else {
    if (-not (Test-Path $ConfigPath)) {
        throw "Could not find block list: $ConfigPath"
    }
    $ids = ConvertTo-BlockIdList -Text (Get-Content -Raw -LiteralPath $ConfigPath)
    if ($ids.Count -eq 0) {
        throw "No block IDs were found in $ConfigPath."
    }
}

$texturesDir = Join-Path $PackRoot "textures\blocks"
New-Item -ItemType Directory -Force -Path $texturesDir | Out-Null
New-TransparentPng -Path (Join-Path $texturesDir "xtra_invisible.png")
New-PackIcon -Path (Join-Path $PackRoot "pack_icon.png")

$blocks = [ordered]@{
    format_version = "1.19.30"
}

foreach ($id in $ids) {
    $blocks[$id] = [ordered]@{
        textures = "xtra_invisible"
        carried_textures = "xtra_invisible"
        blockshape = "invisible"
    }
}

$blocksJson = $blocks | ConvertTo-Json -Depth 8
Set-Content -LiteralPath (Join-Path $PackRoot "blocks.json") -Value $blocksJson -Encoding UTF8

$zipPath = "$OutputPath.zip"
if (Test-Path $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}
if (Test-Path $OutputPath) {
    Remove-Item -LiteralPath $OutputPath -Force
}

Compress-Archive -Path (Join-Path $PackRoot "*") -DestinationPath $zipPath -Force
Move-Item -LiteralPath $zipPath -Destination $OutputPath

Write-Host "Built $OutputPath"
if ($mode -eq "show_only") {
    Write-Host "Mode: show only listed visible blocks"
}
else {
    Write-Host "Mode: hide selected blocks"
}
Write-Host "Blocks made invisible:"
foreach ($id in $ids) {
    Write-Host " - $id"
}
